document.addEventListener("DOMContentLoaded", function () {
    // Funciones
    // const funcion = function(a, b) {
    //     return a+b;
    // }
    // alert(`El resultado de la suma es: ${funcion(3, 2)}`);

    // const yahya = Function("hola", "mundo", "return hol+''+mundo");
    // alert(yahya)

    // Funcion anonima autoinvocada
    /*
    const a = 3;
    const b = 5;

    alert((function(a, b){return `La suma es: ${a + b}`;}(a, b))); //A averiguar

    const cabezera = document.querySelector('h1');
    cabezera.addEventListener("click", funcion);

    function funcion() {
        alert("Hola Mundo!");
    } 
    */

    //   ------------------- PARAMETROS ---------------------
    //los parametros son los nombres que se utilizan en la definicion de la funcion
    // Los argumentos son los valores que se pasan a la funcion cuando se invoca
    // 1. No se especifica el tipo de datos de los parametros
    // 2. No se verifica el tipo de dato en la funcion
    // 3. No se verifica el numero de argumentos que se pasan a la funcion

    function sumar(a, b) {
        // Como saber que arguments es iterable
        // console.log(arguments[Symbol.iterator]);
        for(const elemento of arguments) {
            console.log(elemento)
        }
        if (b === undefined) b = 0;
        return a + b;
    }
    console.log(sumar(3, 4));
});
